﻿using System;
using static System.Console;
/*
 * Nasr Bin Safwan + Madisen Dove
 * Intro to Programming
 * with Help from Janell and Karen :-)
 */

namespace TriviaGameGroup
{
    class MainClass
    {

        public static void Main(string[] args)
        {
            //Instantiates the game!!
            Game game = new Game();

        }
    }
}
